package com.example.onlinehouserentalmanagement;

/**
 * This class will sent mail and email to javaMailAppActivity
 * so that user's mail can come to this location.
 */
public class Utils
{
    public static final String EMAIL="nusratislam707@gmail.com";
    public static final String PASSWORD="nusrat0405";
}
